package com.example.wjsur0329.seeker.data;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by wjsur0329 on 2017-12-16.
 */

public class DataManager {
    private static DataManager instance = new DataManager();
    private String serverAddress;
    private DataInterface handler;

    private DataManager() { }

    public static DataManager getInstance(DataInterface handler) {
        instance.handler = handler;
        return instance;
    }

    public void setServerIP(String address){
        this.serverAddress = address;
    }

    public void getItems(){
        // server에 요청 보내고 응답온 JSON 을 DataBean Array로 생성해서 return
        try {
            URL url = new URL("http://"+"10.80.163.200:8080"+"/project/insert");
            new AsyncTask<URL, Void, String>() {
                @Override
                protected String doInBackground(URL... params) {
                    String result = new String();
                    if(params == null || params.length < 1)
                        return null;

                    try {
                        HttpURLConnection connection = (HttpURLConnection)params[0].openConnection();
                        Log.i("http", "connected");
                        connection.setRequestMethod("GET"); // get방식
                        connection.setDoOutput(true); // 쓰기모드
                        connection.setDoInput(true); // 읽기모드
                        connection.setUseCaches(false);
                        connection.setDefaultUseCaches(false);

                        InputStream is = connection.getInputStream();
                        StringBuilder builder = new StringBuilder(); //문자열을 담기 위한 객체
                        BufferedReader reader = new BufferedReader(new InputStreamReader(is,"UTF-8")); //문자열 셋 세팅
                        String line;
                        while ((line = reader.readLine()) != null) {
                            builder.append(line+ "\n");
                        }
                        result = builder.toString();
                        Log.i("http", "result=" + result);
                    }catch(IOException me){
                        me.printStackTrace();
                        handler.onDataReceived(null);
                    }
                    return result;
                }

                @Override
                protected void onPostExecute(String s) {
                    super.onPostExecute(s);
                    // DataBean 배열을 반환
                    handler.onDataReceived(null);
                }
            }.execute(url);
        }catch (MalformedURLException e) {
            handler.onDataReceived(null);
        }

    }

    public void updateItem(DataBean item){
        //서버에 찾은 보물 갯수 줄이라는 요청을 보냄
    }
}
