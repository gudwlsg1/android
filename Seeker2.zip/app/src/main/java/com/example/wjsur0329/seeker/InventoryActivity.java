package com.example.wjsur0329.seeker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class InventoryActivity extends AppCompatActivity {

    private ImageButton imageButton1;
    private ImageButton imageButton2;
    private ImageButton imageButton3;
    private ImageButton imageButton4;
    private ImageButton imageButton5;
    private ImageButton imageButton6;
    private ImageButton imageButton7;
    private ImageButton imageButton8;
    private ImageButton imageButton9;
    private ImageButton imageButton10;
    private ImageButton imageButton11;
    private ImageButton imageButton12;
    private ImageButton imageButton13;
    private ImageButton imageButton14;
    private ImageButton imageButton15;
    private ImageButton imageButton16;
    private ImageButton imageButton17;
    private ImageButton imageButton18;
    private ImageButton imageButton19;
    private ImageButton imageButton20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        imageButton1 = (ImageButton)findViewById(R.id.imageButton1);
        imageButton2 = (ImageButton)findViewById(R.id.imageButton2);
        imageButton3 = (ImageButton)findViewById(R.id.imageButton3);
        imageButton4 = (ImageButton)findViewById(R.id.imageButton4);
        imageButton5 = (ImageButton)findViewById(R.id.imageButton5);
        imageButton6 = (ImageButton)findViewById(R.id.imageButton6);
        imageButton7 = (ImageButton)findViewById(R.id.imageButton7);
        imageButton8 = (ImageButton)findViewById(R.id.imageButton8);
        imageButton9 = (ImageButton)findViewById(R.id.imageButton9);
        imageButton10 = (ImageButton)findViewById(R.id.imageButton10);
        imageButton11 = (ImageButton)findViewById(R.id.imageButton11);
        imageButton12 = (ImageButton)findViewById(R.id.imageButton12);
        imageButton13 = (ImageButton)findViewById(R.id.imageButton13);
        imageButton14 = (ImageButton)findViewById(R.id.imageButton14);
        imageButton15 = (ImageButton)findViewById(R.id.imageButton15);
        imageButton16 = (ImageButton)findViewById(R.id.imageButton16);
        imageButton17 = (ImageButton)findViewById(R.id.imageButton17);
        imageButton18 = (ImageButton)findViewById(R.id.imageButton18);
        imageButton19 = (ImageButton)findViewById(R.id.imageButton19);
        imageButton20 = (ImageButton)findViewById(R.id.imageButton20);

        imageButton1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "1번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "2번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "3번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "4번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "5번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton6.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "6번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton7.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "7번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton8.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "8번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton9.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "9번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton10.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "10번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton11.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "11번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton12.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "12번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton13.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "13번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton14.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "14번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton15.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "15번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton16.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "16번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton17.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "17번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton18.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "18번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton19.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "19번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
        imageButton20.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(), "20번 이미지를 클릭하셨습니다.", Toast.LENGTH_LONG).show();
            }
        });
    }
}
