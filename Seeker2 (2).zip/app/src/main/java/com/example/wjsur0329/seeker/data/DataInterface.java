package com.example.wjsur0329.seeker.data;

/**
 * Created by wjsur0329 on 2017-12-16.
 */

public interface DataInterface {
    public void onDataReceived(DataBean[] items);
    public void onUpdateResult(int result);
}

