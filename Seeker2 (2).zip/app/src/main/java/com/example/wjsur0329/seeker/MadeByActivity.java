package com.example.wjsur0329.seeker;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by JSH on 2017-12-16.
 */

public class MadeByActivity extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_madeby);
    }
}
